package com.example.crcalc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrcalcApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrcalcApplication.class, args);
	}

}
