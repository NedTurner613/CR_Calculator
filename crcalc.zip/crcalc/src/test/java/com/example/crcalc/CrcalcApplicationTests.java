package com.example.crcalc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrcalcApplicationTests {

	@Test
	void contextLoads() {
	}

}
